Eyelink('Stoprecording');
Eyelink('CloseFile');

% Eyelink('Shutdown');
