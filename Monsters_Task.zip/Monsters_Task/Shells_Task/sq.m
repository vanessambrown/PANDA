function y=sq(x);
y=squeeze(x);
