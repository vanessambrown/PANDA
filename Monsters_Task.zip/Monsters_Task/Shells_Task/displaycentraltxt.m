[wt]=Screen(wd,'TextBounds',text);
Screen('Drawtext',wd,text,wdw/2-wt(3)/2,wdh/2-wt(4)/2,col);
Screen('Flip', wd);
